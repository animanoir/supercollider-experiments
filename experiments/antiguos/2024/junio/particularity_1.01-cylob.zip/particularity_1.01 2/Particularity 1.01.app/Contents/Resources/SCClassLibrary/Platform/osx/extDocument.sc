/*+ Document {
	*implementationClass { ^CocoaDocument }
}
*/