SCConstructionView : SCUserView{
	*viewClass { ^SCUserView }


}