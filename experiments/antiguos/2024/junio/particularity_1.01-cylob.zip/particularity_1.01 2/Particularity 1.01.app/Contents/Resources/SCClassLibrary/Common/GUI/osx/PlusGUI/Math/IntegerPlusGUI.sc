+ Integer {
	getKeys { _GetKeys }
}

